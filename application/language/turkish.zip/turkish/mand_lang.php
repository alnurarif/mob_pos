<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['company'] = 'Company';
$lang['address'] = 'Address';
$lang['city'] = 'City';
$lang['state'] = 'State';
$lang['zip_code'] = 'Zip Code';
$lang['email'] = 'Email';
$lang['ein'] = 'EIN';
$lang['dln'] = 'Driving License Number';
$lang['comment'] = 'Comment';



$lang['manufacturer'] = 'manufacturer';
$lang['category_id'] = 'Category';
$lang['sub_category'] = 'Sub Category';
